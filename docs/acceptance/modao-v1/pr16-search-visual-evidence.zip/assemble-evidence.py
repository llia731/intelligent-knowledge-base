from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import hashlib,json,shutil,zipfile,subprocess,html,collections
repo=Path('/workspace/intelligent-knowledge-base');w=Path('/workspace/work/pr16');main=w/'evidence';core=w/'core-evidence';diag=w/'diagnostics'
for r in [main,core,diag]:r.mkdir(exist_ok=True)
def cp(a,b):
 b.parent.mkdir(parents=True,exist_ok=True)
 if a.is_dir():shutil.copytree(a,b,dirs_exist_ok=True)
 else:shutil.copy2(a,b)
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sets=['pr11-final','v16-final','v15-final','library-final','search-final'];summary={};hmr=[]
for name in sets:
 assert (w/(name+'.exit')).read_text().strip()=='0',name
 rs=json.load(open(w/name/'results.json'));assert all(r['status']=='pass' for r in rs),name
 summary[name]={'cases':len(rs),'passed':sum(r['status']=='pass' for r in rs),'pageErrors':sum(len(r['pageErrors']) for r in rs),'consoleErrors':sum(len(r['consoleErrors']) for r in rs),'failedRequests':sum(len(r['failedRequests']) for r in rs),'failedDomains':sorted({q['url'].split('/')[2] for r in rs for q in r['failedRequests']})}
 target=main if name=='search-final' else core;cp(w/name,target/name)
 if target==core:cp(w/name/'results.json',main/'existing-53-results'/name/'results.json')
 for p in (w/name).glob('*-trace.zip'):
  with zipfile.ZipFile(p)as z:
   for f in z.namelist():
    if f.endswith('.trace'):
     for line in z.read(f).decode().splitlines():
      e=json.loads(line)
      if e.get('type')=='console' and any(t in e.get('text','') for t in ['hot updated','page reload']):hmr.append({'trace':str(p.relative_to(w)),'event':e['text'],'time':e.get('time')})
assert [summary[n]['cases'] for n in sets]==[6,15,19,13,24];assert not hmr,hmr
dump(w/'final-hmr-audit.json',{'counts':summary,'hotUpdatesOrReloads':hmr})
for root in [main,core,diag]:dump(root/'summary.json',summary);cp(w/'final-hmr-audit.json',root/'final-hmr-audit.json')
for n in ['visual-final','visual-live9-page1','visual-live9-page2','visual-live9-page3']:
 assert (w/(n+'.exit')).read_text().strip()=='0',n;cp(w/n,main/n)
cp(w/'visual-baseline',main/'asset-source');cp(repo/'public/modao/search',main/'assets')
cp(w/'visual-baseline',diag/'visual-baseline');cp(w/'search-baseline',diag/'search-baseline');cp(w/'search-baseline-script.mjs',diag/'scripts/baseline-modao-search-regression.mjs');cp(repo/'scripts/modao-browser-ready.mjs',diag/'scripts/modao-browser-ready.mjs')
for n in ['search-fix1','search-fix2','pr11-baseline','v16-baseline','v15-baseline','library-baseline','pr11-before-toolbar','v16-before-toolbar','v15-before-toolbar','library-before-toolbar','search-before-toolbar']:cp(w/n/'results.json',diag/n/'results.json')
cp(w/'visual-clip-probe',diag/'prototype-clipping-diagnostic')
for n in ['source-result-detail-editor.png','source-result-detail-text.txt','url-domain-before.json','url-domain-before.png']:cp(w/n,diag/n)
# Preserve the genuine intermediate focus assertion failure in full, not just its summary.
cp(w/'v16-before-domain-fix',diag/'v16-intermediate-focus-failure')
cp(w/'v15-intermediate-reload',diag/'v15-intermediate-reload')
for n in ['pr11-before-domain-fix','v15-before-domain-fix','library-before-domain-fix','search-before-domain-fix']:cp(w/n/'results.json',diag/n/'results.json')
focus={'case':'keyboard-layering','intermediateCommit':'63b2280b7556fc499fd092cb99e2baa746fd6e9e','assertion':'Return focus to actual opener','observed':'Immediate evaluate returned false; native failure screenshot shortly afterward already shows the opener focus outline. Radix FocusScope dispatches unmount auto-focus inside setTimeout(0).','classification':'Intermittent timing at immediate assertion; eventual focus restoration observed, not evidence that focus never restores. Original assertions retained; final full serial run reported separately.','dependency':'node_modules/@radix-ui/react-focus-scope/dist/index.mjs:107','noV16CodeOrTestChanges':True}
dump(diag/'v16-intermediate-focus-failure/diagnosis.json',focus)
for p in w.iterdir():
 if p.suffix in ['.log','.exit']:
  dest=main if any(s in p.name for s in ['-final.','visual-live9','extract-assets','zip-inventory']) else diag
  cp(p,dest/'logs'/p.name)
  if any(p.name.startswith(n)for n in ['pr11-final','v16-final','v15-final','library-final']):cp(p,core/'logs'/p.name)
for n in ['zip-inventory.json','font-viewport-proof.json','search-network-boundary.json']:
 if (w/n).exists():cp(w/n,main/n)
oldScripts=['modao-pr11-regression.mjs','modao-v16-regression.mjs','modao-v15-regression.mjs','modao-library-regression.mjs','modao-browser-ready.mjs'];integrity=[]
for name in oldScripts:
 path='scripts/'+name;base=subprocess.check_output(['git','show','2d0c297410adfd2dbcafd7daaa48f0b00505fda7:'+path],cwd=repo);current=(repo/path).read_bytes();assert base==current,name
 integrity.append({'path':path,'baselineSha256':hashlib.sha256(base).hexdigest(),'currentSha256':hashlib.sha256(current).hexdigest(),'unchanged':True});cp(repo/path,core/path)
dump(main/'prior-53-script-integrity.json',integrity);cp(main/'prior-53-script-integrity.json',core/'prior-53-script-integrity.json')
for n in ['modao-search-regression.mjs','modao-search-visual-capture.mjs','modao-search-extract-assets.py','modao-browser-ready.mjs']:cp(repo/'scripts'/n,main/'scripts'/n)
prov={'branch':'feat/modao-search-visual-phase1','baselineCommit':'b57b356ce2c917348573b8d6b35e2b574f05dfae','testedCommit':'6001606bf6ccb7aded2b769a051ea49e2544acac','captureToolCommit':'95a15f8cef39db30f33dbc14f7a5c201de68565c','priorAcceptedCommit':'2d0c297410adfd2dbcafd7daaa48f0b00505fda7','node':'v24.22.1','npm':'11.9.0','chromium':'155.0.8059.79','viewport':{'width':1920,'height':1080,'dpr':1,'zoom':1},'normalizedFont':'Noto Sans CJK SC','prototypeZipSha256':sha(repo/'prototype/智能知识库V1.0.zip'),'priorEvidenceSha256':sha(repo/'docs/acceptance/modao-v1/pr15-library-regression-evidence.zip'),'testState':'isolated contexts, local synthetic data; original source examples visibly labelled and never returned as live results; no vector/semantic/feedback/download service mocked as successful','sourceFullCanvas':'Original top frame is 1920x1080; an additional 1920x1324 real DOM overflow canvas is separately captured with same viewport and no reconstruction.'}
commands=[]
for stage in ['baseline','final']:
 for n,cmd in [('typecheck','npm run typecheck'),('build','npm run build:dev'),('pr11',f'IKB_PR11_OUTPUT=/workspace/work/pr16/pr11-{stage} node scripts/modao-pr11-regression.mjs'),('v16',f'IKB_V16_OUTPUT=/workspace/work/pr16/v16-{stage} node scripts/modao-v16-regression.mjs'),('v15',f'IKB_V15_OUTPUT=/workspace/work/pr16/v15-{stage} node scripts/modao-v15-regression.mjs'),('library',f'IKB_LIBRARY_TEST_OUTPUT=/workspace/work/pr16/library-{stage} node scripts/modao-library-regression.mjs'),('search',f'IKB_SEARCH_TEST_OUTPUT=/workspace/work/pr16/search-{stage} node scripts/modao-search-regression.mjs')]:commands.append({'command':cmd,'cwd':str(repo),'stage':stage,'exit':int((w/(n+'-'+stage+'.exit')).read_text()),'log':n+'-'+stage+'.log','note':'baseline search used the preserved 20-case script; final adds four cases without removing any baseline assertion' if n=='search' else ''})
for name,cmd in [('visual-final','IKB_SEARCH_OUTPUT=/workspace/work/pr16/visual-final node scripts/modao-search-visual-capture.mjs'),('extract-assets','python scripts/modao-search-extract-assets.py /workspace/work/pr16/visual-baseline/source-geometry.json public/modao/search'),('zip-inventory','python scripts/modao-inventory.py prototype/智能知识库V1.0.zip --output /workspace/work/pr16/zip-inventory.json')]:commands.append({'command':cmd,'cwd':str(repo),'exit':int((w/(name+'.exit')).read_text()),'log':name+'.log'})
for i in [1,2,3]:commands.append({'command':f'IKB_SEARCH_CAPTURE_MODE=react IKB_SEARCH_FIXTURE=live9 IKB_SEARCH_PAGE={i} IKB_SEARCH_OUTPUT=/workspace/work/pr16/visual-live9-page{i} node scripts/modao-search-visual-capture.mjs','cwd':str(repo),'exit':int((w/(f'visual-live9-page{i}.exit')).read_text()),'log':f'visual-live9-page{i}.log'})
commands.append({'command':'IKB_V16_OUTPUT=/workspace/work/pr16/v16-final node scripts/modao-v16-regression.mjs','cwd':str(repo),'stage':'intermediate 63b2280, concurrent suites; archived as v16-intermediate-focus-failure','exit':1,'log':'v16-before-domain-fix.log','note':'Original assertion retained. Final complete serial run is a separate entry; original intermediate output directory renamed for preservation.'})
commands.append({'command':'IKB_V15_OUTPUT=/workspace/work/pr16/v15-final node scripts/modao-v15-regression.mjs','cwd':str(repo),'stage':'intermediate 6001606, document write coincided with reload; archived separately','exit':1,'log':'v15-intermediate-reload.log','note':'Complete 19-case suite repeated after all project writes stopped, with unchanged assertions.'})
patch=subprocess.check_output(['git','diff',prov['baselineCommit'],prov['testedCommit'],'--','src','scripts','public/modao/search'],cwd=repo)
for root in [main,core,diag]:dump(root/'provenance.json',prov);dump(root/'commands.json',commands);(root/'fixes.patch').write_bytes(patch)
# Original screenshots are never changed. Comparison figures below are explicitly derived.
fig=main/'comparison';fig.mkdir(exist_ok=True);font=ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',18)
src=Image.open(main/'visual-final/source.png').convert('RGB');react=Image.open(main/'visual-final/react.png').convert('RGB');before=Image.open(diag/'visual-baseline/react.png').convert('RGB')
def sheet(name,images,titles,crop=None):
 images=[im.crop(crop)if crop else im for im in images];ww=images[0].width;hh=max(im.height for im in images);im=Image.new('RGB',(ww*len(images),hh+42),'#f1f5f9');d=ImageDraw.Draw(im)
 for i,(x,title)in enumerate(zip(images,titles)):im.paste(x,(i*ww,42));d.text((i*ww+12,8),title,font=font,fill='#0d1117')
 im.save(fig/name)
sheet('full-viewport.png',[src,react],['Modao / original static design','React / visibly labelled reference examples'])
sheet('before-source-after.png',[before,src,react],['Before / PR16 b57b356','Modao / actual original DOM','After / 6001606'],(445,88,1725,1055))
live=[Image.open(main/f'visual-live9-page{i}/react.png').convert('RGB')for i in [1,2,3]];sheet('real-pagination-9.png',live,['Actual local query / page 1','Actual local query / page 2','Actual local query / page 3'],(725,478,1725,1080))
bmeta=json.load(open(diag/'visual-baseline/react-geometry.json'));rmeta=json.load(open(main/'visual-final/react-geometry.json'))
def find(meta,cls):return next(a for a in meta['items']if a['cls']==cls)
def xywh(a):return[a['rect'][k]for k in ['x','y','width','height']]
anchors=[('A','横向检索卡',[445,168,1280,286],'search-intro card mt-4 p-4','search-intro card'),('B','检索输入区',[466,241,1238,56],None,'search-query'),('C','高级语法条',[466,353,1238,80],'search-syntax mt-4','search-syntax'),('D','左侧筛选栏',[445,478,256,846],None,'search-filters card'),('E','结果工具条',[724.984375,478,1000,36],None,'search-results-head'),('F','首张结果卡',[724.984375,530,1000,151.5],None,'search-result card'),('G','结果分页',[724.71875,1185.25,1000.265625,34],None,'pager search-pager')]
geo=[{'id':key,'label':name,'sourceXYWH':s,'beforeXYWH':xywh(find(bmeta,bc))if bc else None,'afterXYWH':xywh(find(rmeta,rc)),'afterDelta':[round(v-u,5)for u,v in zip(s,xywh(find(rmeta,rc)))]}for key,name,s,bc,rc in anchors]
# The original select's measured x/width demonstrate the final 4px toolbar correction.
selection=lambda meta,word:next(a for a in meta['items']if a['tag']=='SELECT' and word in a['text'])
bs=selection(bmeta,'排序');rs=selection(rmeta,'排序');ss=[1362.984375,478,166,36]
geo.append({'id':'H','label':'排序下拉框','sourceXYWH':ss,'beforeXYWH':xywh(bs),'afterXYWH':xywh(rs),'afterDelta':[round(v-u,5)for u,v in zip(ss,xywh(rs))]})
dump(fig/'geometry-comparison.json',geo)
srcfull=Image.open(main/'visual-final/source-full.png').convert('RGB');reactfull=Image.open(main/'visual-final/react-full.png').convert('RGB');annot=[]
for kind,image in [('source',srcfull),('react',reactfull)]:
 im=image.crop((445,88,1725,1324));d=ImageDraw.Draw(im)
 for a in geo:
  x,y,ww,hh=a['sourceXYWH']if kind=='source'else a['afterXYWH'];x-=445;y-=88;d.rectangle((x,y,x+ww-1,y+hh-1),outline='#e11d48',width=2);d.rectangle((x,y,x+24,y+24),fill='#e11d48');d.text((x+3,y-1),a['id'],font=font,fill='white')
 annot.append(im)
sheet('structure.png',annot,['Modao A-G / real overflow canvas','React A-G / measured DOM'])
def picture(p,label):return '<figure><figcaption>'+html.escape(label)+'</figcaption><a href="'+p+'"><img loading="lazy" src="'+p+'"></a></figure>'
for root,folders,kind in [(main,['search-final'],'main'),(core,sets[:-1],'core'),(diag,['search-baseline','v16-intermediate-focus-failure','v15-intermediate-reload'],'diagnostics')]:
 parts=['<!doctype html><meta charset="utf-8"><title>PR16 search independent audit</title><style>body{font:15px system-ui;margin:24px;color:#0d1117}img{max-width:100%;height:auto}figure{margin:16px 0}summary{cursor:pointer}pre{white-space:pre-wrap}</style><h1>PR16 智能检索独立验收 — '+kind+'</h1><p>1920×1080 / DPR1。原型示例与实际本地关键词结果分开；没有语义/向量/复杂语法/真实相关度服务。复制使用真实剪贴板。</p><p><a href="summary.json">完整 77 项统计</a> | <a href="commands.json">命令/退出码</a> | <a href="provenance.json">版本与来源</a> | <a href="fixes.patch">修复差异</a> | <a href="manifest.json">SHA256 清单</a></p>']
 if kind=='main':
  for n in ['full-viewport.png','before-source-after.png','structure.png','real-pagination-9.png']:parts.append(picture('comparison/'+n,n))
  parts.append('<p>原有 53 项的完整截图与 trace 在独立的 existing-53 ZIP；本包保留其全部 JSON 结果及脚本未改变证明。分别解压三个包，避免覆盖各自 index/manifest。</p><details><summary>原始 top / native / full-page / actual local screenshots</summary>')
  for folder in ['visual-final','visual-live9-page1','visual-live9-page2','visual-live9-page3']:
   for p in sorted((root/folder).glob('*.png')):parts.append(picture(p.relative_to(root).as_posix(),str(p.relative_to(root))))
  parts.append('</details>')
 if kind=='diagnostics':
  for p in sorted((root/'visual-baseline').glob('*.png')):parts.append(picture(p.relative_to(root).as_posix(),str(p.relative_to(root))))
 for folder in folders:
  rs=json.load(open(root/folder/'results.json'));parts.append('<h2>'+folder+f' {sum(r["status"]=="pass" for r in rs)}/{len(rs)}</h2>')
  for r in rs:
   parts.append('<details class="case"><summary>'+html.escape(r['status']+' '+r['id'])+'</summary><pre>'+html.escape(json.dumps(r,ensure_ascii=False,indent=2))+'</pre><a href="'+folder+'/'+r['id']+'-trace.zip">Playwright trace</a>')
   for p in sorted((root/folder).glob(r['id']+'-*.png')):parts.append(picture(p.relative_to(root).as_posix(),p.name))
   parts.append('</details>')
 parts.append('<p>外部字体/Grok 代理失败原样保留。没有跳过失败测试；未知标签、原文件下载、反馈服务等能力明确标记。</p>');(root/'index.html').write_text('\n'.join(parts))
print('ASSEMBLED',json.dumps(summary,ensure_ascii=False))
