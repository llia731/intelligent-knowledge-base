PR #15 independent library visual regression / 2026-11-05 UTC
Unzip and open index.html directly. Native and shared-font original screenshots are separate; comparison/ holds derived figures.
Runtime SVG assets and their provenance are in assets/; source extraction input is in asset-source/.
No real move/export/version/sharing service is implemented. All test data/passwords are synthetic.
Reuse project Playwright dependencies: npx playwright show-trace <case>-trace.zip
Manifest lists all other files with byte counts and SHA256; ZIP hash is distributed separately.
