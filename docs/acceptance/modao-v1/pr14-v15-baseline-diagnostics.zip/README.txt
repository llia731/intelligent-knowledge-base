PR #14 V15 independent regression / 2026-11-05 UTC
Unzip, then open index.html directly. Click images for original dimensions.
Native and normalized screenshots are separate; comparison/ contains derived figures.
All test data and passwords are synthetic. Real sharing service is NOT implemented.
Playwright traces: reuse project dependencies and run npx playwright show-trace <case>-trace.zip
Manifest lists SHA256 and size of all other files. Archive SHA256 is distributed separately.
report.md links downloadable companion archives; diagnostics references report figures on the repository.
