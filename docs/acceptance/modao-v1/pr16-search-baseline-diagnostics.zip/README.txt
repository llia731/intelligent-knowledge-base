PR #16 independent search audit / 2026-11-05 UTC
Extract the three ZIP files into SEPARATE folders and open each index.html.
Existing 53 cases and search-specific 24 cases are separate; summary.json covers all 77.
Native/top/full-canvas and normalized images are separate. comparison/ contains derived figures.
Reference prototype examples are labelled; live data is synthetic local test data, not production. No semantic/vector/feedback/download service is implemented.
Use existing project dependencies: npx playwright show-trace <case>-trace.zip
The baseline 20-case script is preserved separately; all 53 existing scripts retain their assertions.
manifest.json hashes every other file. Archive SHA256 is distributed separately.
