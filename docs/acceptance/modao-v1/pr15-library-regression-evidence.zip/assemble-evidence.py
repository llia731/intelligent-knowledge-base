from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageChops,ImageStat
import hashlib,json,shutil,zipfile,subprocess,html,collections
repo=Path('/workspace/intelligent-knowledge-base');w=Path('/workspace/work/pr15');out=w/'evidence';diag=w/'diagnostics'
for r in [out,diag]:r.mkdir(exist_ok=True)
def cp(src,dest):
 dest.parent.mkdir(parents=True,exist_ok=True)
 if src.is_dir():shutil.copytree(src,dest,dirs_exist_ok=True)
 else:shutil.copy2(src,dest)
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
names=['pr11-final','v16-final','v15-final','library-final']
summary={};hmr=[]
for name in names:
 assert (w/(name+'.exit')).read_text().strip()=='0',name
 results=json.load(open(w/name/'results.json'));assert all(r['status']=='pass' for r in results),name
 cp(w/name,out/name);summary[name]={'cases':len(results),'passed':sum(r['status']=='pass' for r in results),'pageErrors':sum(len(r['pageErrors']) for r in results),'consoleErrors':sum(len(r['consoleErrors']) for r in results),'failedRequests':sum(len(r['failedRequests']) for r in results),'failedDomains':sorted({q['url'].split('/')[2] for r in results for q in r['failedRequests']})}
 for p in (w/name).glob('*-trace.zip'):
  with zipfile.ZipFile(p) as z:
   for f in z.namelist():
    if f.endswith('.trace'):
     for line in z.read(f).decode().splitlines():
      e=json.loads(line)
      if e.get('type')=='console' and any(t in e.get('text','') for t in ['hot updated','page reload']):hmr.append({'trace':str(p.relative_to(w)),'event':e['text'],'time':e.get('time')})
assert [summary[n]['cases'] for n in names]==[6,15,19,13];assert not hmr,hmr
dump(w/'final-hmr-audit.json',{'counts':summary,'hotUpdatesOrReloads':hmr});dump(out/'summary.json',summary)
for n in ['visual-final','visual-matched-final','v15-visual-final']:
 assert (w/(n+'.exit')).read_text().strip()=='0';cp(w/n,out/n)
cp(w/'visual-baseline',diag/'visual-baseline')
for n in ['pr11-baseline','v16-baseline','v15-baseline','v16-pass1','library-init-failure','library-fix1','library-pass1','pr11-pass2','v16-pass2','v15-pass2','library-pass2','pr11-pre-hydration','v16-pre-hydration','v15-pre-hydration','library-pre-hydration','pr11-local-gate-round','v16-local-gate-round','v15-local-gate-round','library-local-gate-round']:
 cp(w/n/'results.json',diag/n/'results.json')
for folder,case in [('v16-pass1','roles-permissions'),('library-init-failure','unsupported-is-honest'),('v15-pre-hydration','discard-cancel'),('library-pre-hydration','project-kind-filters'),('pr11-local-gate-round','keys-legacy'),('v16-local-gate-round','partial-preferences-migration'),('library-local-gate-round','metadata-count-honesty')]:
 for p in (w/folder).glob(case+'-*'):cp(p,diag/folder/p.name)
for p in w.iterdir():
 if p.suffix in ['.log','.exit']:
  target=out if any(t in p.name for t in ['-final.','extract-assets','zip-inventory']) else diag
  cp(p,target/'logs'/p.name)
for n in ['font-before-proof.json','role-probe.json','intermediate-hmr-timeline.json','initialization-race-summary.json','1280-before-geometry.json','1280-before.png']:cp(w/n,diag/n)
for n in ['final-hmr-audit.json','zip-inventory.json','font-proof.json']:cp(w/n,out/n)
cp(repo/'public/modao/library',out/'assets')
cp(w/'source-enriched',out/'asset-source')
for p in ['modao-browser-ready.mjs','modao-library-regression.mjs','modao-library-visual-capture.mjs','modao-library-extract-assets.py','modao-v15-regression.mjs','modao-v16-regression.mjs','modao-pr11-regression.mjs','modao-v15-visual-capture.mjs','fixtures/modao-library-documents.json']:
 cp(repo/'scripts'/p,out/'scripts'/p)
prov={'branch':'feat/modao-library-visual-phase1','baselineCommit':'37cda325ee6fa64782e24c98d94ca3fd8585fd56','testedBusinessCommit':'1dcefff91bede669b80d8ad3390d06c80576e2ab','qaReadinessCommit':'1dcefff91bede669b80d8ad3390d06c80576e2ab','node':'v24.22.1','npm':'11.9.0','chromium':'155.0.8059.79','viewport':{'width':1920,'height':1080,'dpr':1},'fontComparison':'Noto Sans CJK SC; native frames retained separately; no PingFang pixel signoff','prototypeZipSha256':sha(repo/'prototype/智能知识库V1.0.zip'),'authenticAssets':41,'fixture':'Default local seed and a separately labelled four-document fixture copied from original filenames/categories/dates; synthetic text and permissions. Unknown size/tags/capacity stay unknown. No sample card counts copied into live state.'}
commands=[]
for stage in ['baseline','final']:
 for n,cmd in [('typecheck','npm run typecheck'),('build','npm run build:dev'),('pr11',f'IKB_PR11_OUTPUT=/workspace/work/pr15/pr11-{stage} node scripts/modao-pr11-regression.mjs'),('v16',f'IKB_V16_OUTPUT=/workspace/work/pr15/v16-{stage} node scripts/modao-v16-regression.mjs'),('v15',f'IKB_V15_OUTPUT=/workspace/work/pr15/v15-{stage} node scripts/modao-v15-regression.mjs')]:commands.append({'command':cmd,'cwd':str(repo),'stage':stage,'exit':int((w/(n+'-'+stage+'.exit')).read_text()),'log':n+'-'+stage+'.log'})
for name,cmd in [('library-final','IKB_LIBRARY_TEST_OUTPUT=/workspace/work/pr15/library-final node scripts/modao-library-regression.mjs'),('visual-final','IKB_LIBRARY_CAPTURE_MODE=both IKB_LIBRARY_OUTPUT=/workspace/work/pr15/visual-final node scripts/modao-library-visual-capture.mjs'),('visual-matched-final','IKB_LIBRARY_CAPTURE_MODE=react IKB_LIBRARY_FIXTURE=prototype IKB_LIBRARY_OUTPUT=/workspace/work/pr15/visual-matched-final node scripts/modao-library-visual-capture.mjs'),('v15-visual-final','IKB_V15_VISUAL_OUTPUT=/workspace/work/pr15/v15-visual-final node scripts/modao-v15-visual-capture.mjs'),('extract-assets','python scripts/modao-library-extract-assets.py /workspace/work/pr15/source-enriched/source-geometry.json public/modao/library'),('zip-inventory','python scripts/modao-inventory.py prototype/智能知识库V1.0.zip --output /workspace/work/pr15/zip-inventory.json')]:commands.append({'command':cmd,'cwd':str(repo),'exit':int((w/(name+'.exit')).read_text()),'log':name+'.log'})
for root in [out,diag]:dump(root/'provenance.json',prov);dump(root/'commands.json',commands)
patch=subprocess.check_output(['git','diff',prov['baselineCommit'],prov['qaReadinessCommit'],'--','src','scripts','public/modao/library'],cwd=repo)
(out/'fixes.patch').write_bytes(patch);(diag/'fixes.patch').write_bytes(patch)
# Original PNGs are never altered. All comparison, crop, overlay and annotation files below are derived.
fig=out/'comparison';fig.mkdir(exist_ok=True);font=ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',18)
src=Image.open(out/'visual-final/source.png').convert('RGB');actual=Image.open(out/'visual-final/react.png').convert('RGB');matched=Image.open(out/'visual-matched-final/react.png').convert('RGB');before=Image.open(diag/'visual-baseline/react.png').convert('RGB')
def sheet(file,imgs,labels,crop=None):
 imgs=[im.crop(crop) if crop else im for im in imgs];width=imgs[0].width;height=max(im.height for im in imgs);canvas=Image.new('RGB',(width*len(imgs),height+42),'#f1f5f9');d=ImageDraw.Draw(canvas)
 for i,(im,label) in enumerate(zip(imgs,labels)):canvas.paste(im,(width*i,42));d.text((width*i+12,8),label,font=font,fill='#0d1117')
 canvas.save(fig/file)
sheet('full-default.png',[src,actual],['Modao / original sample','React / actual local documents'])
sheet('full-matched.png',[src,matched],['Modao / original sample','React / labelled 4-document visual fixture'])
sheet('before-source-after.png',[before,src,actual],['Before / PR15 37cda32','Modao / real original resources','After / business 1dcefff'],(445,88,1725,1040))
bmeta=json.load(open(diag/'visual-baseline/react-geometry.json'));rmeta=json.load(open(out/'visual-final/react-geometry.json'));smeta=json.load(open(out/'visual-final/source-geometry.json'))
def item(meta,cls=None,text=None,tag=None):return next(a for a in meta['items'] if (cls is None or a['cls']==cls) and (text is None or a['text']==text) and (tag is None or a['tag']==tag))
def xywh(a):return [a['rect'][k] for k in ['x','y','width','height']]
anchors=[('A','分类导航', [445,168,302,662], item(bmeta,cls='library-sidebar card h-fit p-4'),item(rmeta,cls='library-navigation card')),('B','知识库列表',[770.984375,168,954,254],item(bmeta,cls='library-collections card p-4'),item(rmeta,cls='library-collections')),('C','蓝色封面',[771.984375,209,305.328125,112],item(bmeta,cls='library-cover'),item(rmeta,cls='library-cover')),('D','文档管理区',[770.984375,445.984375,954,483.125],item(bmeta,cls='library-documents card mt-4 p-4'),item(rmeta,cls='library-documents card')),('E','文档管理标题',[787.984375,469.984375,64,24],item(bmeta,text='文档管理',tag='H2'),item(rmeta,text='文档管理',tag='H2')),('F','底部分页',[771.984375,873.109375,952,55],None,item(rmeta,cls='library-pagination'))]
geometry=[{'id':k,'label':label,'sourceXYWH':s,'beforeXYWH':xywh(old) if old else None,'afterXYWH':xywh(new),'afterDelta':[round(b-a,5) for a,b in zip(s,xywh(new))]} for k,label,s,old,new in anchors];dump(fig/'geometry-comparison.json',geometry)
annotated=[]
for kind,im in [('source',src),('react',actual)]:
 im=im.crop((445,88,1725,1040));d=ImageDraw.Draw(im)
 for a in geometry:
  x,y,ww,hh=a['sourceXYWH'] if kind=='source' else a['afterXYWH'];x-=445;y-=88;d.rectangle((x,y,x+ww-1,y+hh-1),outline='#e11d48',width=2);d.rectangle((x,y,x+24,y+24),fill='#e11d48');d.text((x+3,y-1),a['id'],font=font,fill='white')
 annotated.append(im)
sheet('structure.png',annotated,['Modao / anchors A-F','React / measured DOM'])
cover_metrics=[];cover_strips=[]
for color,x in [('blue',772),('purple',1095),('green',1419)]:
 a=src.crop((x,209,x+305,321));b=actual.crop((x,209,x+305,321));diff=ImageChops.difference(a,b);stat=ImageStat.Stat(diff);pixels=list(diff.getdata());cover_metrics.append({'cover':color,'cropXYWH':[x,209,305,112],'meanAbsoluteRGBDelta':stat.mean,'pixelsAnyChannelAbove2':sum(max(p)>2 for p in pixels),'totalPixels':len(pixels),'limitations':'Integer crop of subpixel-positioned source; descriptive metric only, no acceptance threshold invented.'});cover_strips.append((a,b))
canvas=Image.new('RGB',(915,266),'#f1f5f9');d=ImageDraw.Draw(canvas);d.text((8,4),'Original SVG backgrounds + geometry / Modao above, React below',font=font,fill='#0d1117')
for i,(a,b) in enumerate(cover_strips):canvas.paste(a,(305*i,34));canvas.paste(b,(305*i,150))
canvas.save(fig/'authentic-covers.png');dump(fig/'cover-pixel-metrics.json',cover_metrics)
sheet('1280-before-after.png',[Image.open(diag/'1280-before.png').convert('RGB'),Image.open(out/'library-final/responsive-viewports-1280-top.png').convert('RGB')],['1280px before / title overlapped by 6px','1280px after / tested no-overlap'])
# Browser-readable offline evidence galleries.
def picture(file,label):return '<figure><figcaption>'+html.escape(label)+'</figcaption><a href="'+file+'"><img loading="lazy" src="'+file+'"></a></figure>'
for root,folders,isdiag in [(out,names,False),(diag,['v16-pass1','library-init-failure','v15-pre-hydration','library-pre-hydration','pr11-local-gate-round','v16-local-gate-round','library-local-gate-round'],True)]:
 parts=['<!doctype html><meta charset="utf-8"><title>PR15 library audit</title><style>body{font:15px system-ui;margin:24px;color:#0d1117}img{max-width:100%;height:auto}figure{margin:16px 0}summary{cursor:pointer}pre{white-space:pre-wrap}</style><h1>PR15 知识管理独立验收</h1><p>1920×1080 / DPR1；原生与 Noto Sans CJK SC 图像分别保留。SVG 路径来自真实墨刀 ZIP，未知容量/标签不伪造。</p><p><a href="provenance.json">来源与版本</a> | <a href="commands.json">命令和退出码</a> | <a href="fixes.patch">修复差异</a> | <a href="manifest.json">SHA256 清单</a></p>']
 if not isdiag:
  for f in ['full-matched.png','before-source-after.png','structure.png','authentic-covers.png','1280-before-after.png']:parts.append(picture('comparison/'+f,f))
  parts.append('<details><summary>原始截图、真实本地数据截图与 V15 当前截图</summary>')
  for folder in ['visual-final','visual-matched-final','v15-visual-final']:
   for p in sorted((root/folder).glob('*.png')):parts.append(picture(p.relative_to(root).as_posix(),str(p.relative_to(root))))
  parts.append('</details>')
 else:
  parts.append(picture('1280-before.png','1280px 下标题与描述重叠 6px'))
  for p in sorted((root/'visual-baseline').glob('*.png')):parts.append(picture(p.relative_to(root).as_posix(),str(p.relative_to(root))))
 for folder in folders:
  rs=json.load(open(root/folder/'results.json'));parts.append('<h2>'+folder+'</h2>')
  for r in rs:
   if isdiag and r['status']=='pass':continue
   parts.append('<details class="case"><summary>'+html.escape(r['status']+' '+r['id'])+'</summary><pre>'+html.escape(json.dumps(r,ensure_ascii=False,indent=2))+'</pre><a href="'+folder+'/'+r['id']+'-trace.zip">Playwright trace</a>')
   for p in sorted((root/folder).glob(r['id']+'-*.png')):parts.append(picture(p.relative_to(root).as_posix(),p.name))
   parts.append('</details>')
 parts.append('<p>移动/导出/版本管理未实现；本地推荐摘要不等同真实分享。原始失败、热更新时间线、初始化误报及外部代理错误均保留。</p>');(root/'index.html').write_text('\n'.join(parts))
print('ASSEMBLED',json.dumps(summary,ensure_ascii=False));print('Cover metrics',json.dumps(cover_metrics))
