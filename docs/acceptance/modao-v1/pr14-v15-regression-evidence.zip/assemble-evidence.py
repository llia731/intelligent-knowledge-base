from pathlib import Path
import json, hashlib, shutil, zipfile, subprocess, html, collections
from PIL import Image, ImageDraw, ImageFont, ImageChops
repo=Path('/workspace/intelligent-knowledge-base'); work=Path('/workspace/work/pr14'); final=work/'evidence'; diag=work/'diagnostics'
for root in [final,diag]: root.mkdir(exist_ok=True)
def cp(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 if src.is_dir(): shutil.copytree(src,dst,dirs_exist_ok=True)
 else: shutil.copy2(src,dst)
def dump(p,x): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['pr11-final','v16-final','v15-final','visual-final']:
 assert (work/(n+'.exit')).read_text().strip()=='0',n
 cp(work/n,final/n)
for n in ['pr11-baseline','v16-baseline','pr11-pass1','v16-pass1','v15-pass1','v15-fix1','pr11-pass2','v16-pass2','v15-pass2']:
 cp(work/n/'results.json',diag/n/'results.json')
cp(work/'v15-baseline',diag/'v15-baseline')
for p in work.iterdir():
 if p.suffix in ['.log','.exit']:
  cp(p,(diag if 'baseline' in p.name or 'pass1' in p.name or 'fix1' in p.name or 'pass2' in p.name else final)/'logs'/p.name)
cp(work/'source'/'plan',final/'source-previous');cp(work/'source'/'verification.json',final/'source-verification.json')
for p in (work/'source-fresh').glob('v15-*'): cp(p,final/'source-fresh'/p.name)
for n in ['modao-v15-regression.mjs','modao-v15-visual-capture.mjs','modao-pr11-regression.mjs','modao-v16-regression.mjs','modao-v15-v16-plan-capture.mjs']:
 cp(repo/'scripts'/n,final/'scripts'/n);cp(repo/'scripts'/n,diag/'scripts'/n)
# Pin the baseline test definition too; it had 18 cases before the extra real-mouse case.
# The recorded baseline results/traces retain the exact executed assertions and call logs.
prov={'branch':'feat/modao-v15-share-dialog','baselineCommit':'c4f7707a8e4a5b4248809734657a8d01af6f558a','testedBusinessCommit':'a27e9def3bca1f0cc286a823e1388b779d38e212','initialFixCommit':'92a770e7630b9c48f021cdaa8299eef9bfc883d1','node':'v24.22.1','npm':'11.9.0','chromium':'155.0.8059.79','viewport':{'width':1920,'height':1080,'dpr':1},'normalizedFont':'Noto Sans CJK SC','prototypeZip':{'path':'prototype/智能知识库V1.0.zip','bytes':(repo/'prototype/智能知识库V1.0.zip').stat().st_size,'sha256':sha(repo/'prototype/智能知识库V1.0.zip')},'previousEvidenceSha256':sha(repo/'docs/acceptance/modao-v1/pr11-regression-evidence.zip'),'state':'fresh isolated browser context per test; synthetic local data only; screenshot summary is an unsaved source-text draft; no fake URL/service','sourceMethod':'Existing real Modao hotspot and DOM/SVG capture at 1:1; fresh V15 captures identical to prior manifest; editor/native/shared-font frames preserved. No image reconstruction.'}
commands=[]
for stage in ['baseline','final']:
 for task,command in [('typecheck','npm run typecheck'),('build','npm run build:dev'),('pr11',f'IKB_PR11_OUTPUT=/workspace/work/pr14/pr11-{stage} node scripts/modao-pr11-regression.mjs'),('v16',f'IKB_V16_OUTPUT=/workspace/work/pr14/v16-{stage} node scripts/modao-v16-regression.mjs'),('v15',f'IKB_V15_OUTPUT=/workspace/work/pr14/v15-{stage} node scripts/modao-v15-regression.mjs')]:
  name=task+'-'+stage;commands.append({'command':command,'cwd':str(repo),'exit':int((work/(name+'.exit')).read_text()),'log':name+'.log','stage':stage})
for name,command in [('visual-final','IKB_V15_VISUAL_OUTPUT=/workspace/work/pr14/visual-final node scripts/modao-v15-visual-capture.mjs'),('source-fresh','IKB_PLAN_OUTPUT=/workspace/work/pr14/source-fresh node scripts/modao-v15-v16-plan-capture.mjs')]: commands.append({'command':command,'cwd':str(repo),'exit':int((work/(name+'.exit')).read_text()),'log':name+'.log'})
for root in [final,diag]: dump(root/'provenance.json',prov);dump(root/'commands.json',commands)
patch=subprocess.check_output(['git','diff',prov['baselineCommit'],prov['testedBusinessCommit'],'--','src','scripts'],cwd=repo)
(final/'fixes.patch').write_bytes(patch);(diag/'fixes.patch').write_bytes(patch)
# Raw originals remain untouched; the following are explicitly derived comparison images.
visual=final/'comparison';visual.mkdir(exist_ok=True)
source=Image.open(final/'source-fresh/v15-share.png').convert('RGB');react=Image.open(final/'visual-final/source-summary-draft.png').convert('RGB');before=Image.open(diag/'v15-baseline/layout-fields-default-normalized.png').convert('RGB')
fontpath='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';font=ImageFont.truetype(fontpath,18)
def sheet(name,images,titles,crop=False):
 size=(672,820) if crop else (1920,1080);im=Image.new('RGB',(size[0]*len(images),size[1]+42),'#f1f5f9');d=ImageDraw.Draw(im)
 for i,(x,title) in enumerate(zip(images,titles)):
  v=x.crop((752,130,1424,950)) if crop else x
  im.paste(v,(i*size[0],42));d.text((i*size[0]+12,8),title,font=font,fill='#0d1117')
 im.save(visual/name)
sheet('full-viewport.png',[source,react],['Modao / 1920 x 1080 / DPR 1','React / 1920 x 1080 / DPR 1'])
sheet('before-source-after.png',[before,source,react],['Before / baseline c4f7707','Modao / verified source','After / business a27e9de'],True)
sc=source.crop((752,130,1424,950));rc=react.crop((752,130,1424,950));Image.blend(sc,rc,.5).save(visual/'overlay.png');ImageChops.difference(sc,rc).save(visual/'pixel-difference.png')
meta=json.load(open(final/'visual-final/source-summary-draft-geometry.json'));els=meta['elements']
anchors=[('A','sd-enable',(773,207,630,72)),('B','sd-scopes',(773,327,630,62)),('C','sd-field sd-department',(773,401,630,36)),('D','sd-cols',(773,457,630,82)),('E','sd-field sd-link-field',(773,559,630,62)),('F','sd-channel-buttons',(773,669,630,38)),('G','sd-field sd-summary',(773,727,630,138)),('H','sd-footer',(753,885,670,64))]
geometry=[]; annotated=[]
for kind,img in [('Modao',sc),('React',rc)]:
 im=img.copy();d=ImageDraw.Draw(im)
 for key,cls,s in anchors:
  e=next(e for e in els if e['cls']==cls);r=e['rect'];t=(r['x'],r['y'],r['width'],r['height'])
  if kind=='Modao': geometry.append({'anchor':key,'reactSelector':'.'+cls.replace(' ','.'),'sourceXYWH':s,'reactXYWH':t,'deltaXYWH':[round(b-a,4) for a,b in zip(s,t)]})
  x,y,w,h=s if kind=='Modao' else t;x-=752;y-=130
  d.rectangle((x,y,x+w-1,y+h-1),outline='#e11d48',width=2);d.rectangle((x,y,x+21,y+25),fill='#e11d48');d.text((x+3,y),key,font=font,fill='white')
 annotated.append(im)
sheet('structure-anchors.png',annotated,['Modao A-H (source coordinates)','React A-H (measured DOM)']) if False else None
im=Image.new('RGB',(1344,862),'#f1f5f9');d=ImageDraw.Draw(im)
for i,x in enumerate(annotated): im.paste(x,(672*i,42));d.text((672*i+12,8),['Modao A-H (source coordinates)','React A-H (measured DOM)'][i],font=font,fill='#0d1117')
im.save(visual/'structure-anchors.png');dump(visual/'geometry-comparison.json',geometry)
# Galleries are usable offline after unzip, without CDNs.
def img_html(p,label): return '<figure><figcaption>'+html.escape(label)+'</figcaption><a href="'+html.escape(p)+'"><img loading="lazy" src="'+html.escape(p)+'"></a></figure>'
def gallery(root,isdiag):
 parts=['<!doctype html><meta charset="utf-8"><title>PR14 V15 '+('原始失败证据' if isdiag else '独立回归证据')+'</title><style>body{font:15px system-ui;margin:24px;color:#0d1117}img{max-width:100%;height:auto}figure{margin:16px 0}summary{cursor:pointer}pre{white-space:pre-wrap}table{border-collapse:collapse}td,th{border:1px solid #ddd;padding:6px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}</style><h1>PR14 V15 '+('原始失败证据' if isdiag else '独立回归证据')+'</h1><p>1920×1080 / DPR1；Noto Sans CJK SC 仅用于统一字形。原始与 native 截图未修改。真实分享服务未接入，仅验证本地推荐摘要。</p><p><a href="provenance.json">来源与版本</a> | <a href="commands.json">实际命令/退出码</a> | <a href="fixes.patch">修复差异</a> | <a href="manifest.json">SHA256 清单</a></p>']
 if not isdiag:
  for p in ['comparison/full-viewport.png','comparison/before-source-after.png','comparison/structure-anchors.png']:
   parts.append(img_html(p,p))
  parts.append('<p>结构 A-H 对应：链接开关卡片、范围卡片、部门、密码/有效期区、链接区、渠道、摘要、底栏。D 容器比源数据高 2px，密码辅助文字已向上对齐，下游锚点无偏移。空链接、禁用颜色、本地保存按钮及服务声明属于明确的无服务模式差异。背景知识管理既有差异不计为 V15 弹窗像素通过。</p>')
  parts.append('<details><summary>原始/统一字体/菜单截图与几何数据</summary>')
  for folder in ['source-fresh','visual-final']:
   for p in sorted((root/folder).glob('*.png')): parts.append(img_html(p.relative_to(root).as_posix(),str(p.relative_to(root))))
  parts.append('</details>')
 folders=['v15-baseline'] if isdiag else ['v15-final','pr11-final','v16-final']
 for folder in folders:
  rs=json.load(open(root/folder/'results.json'));parts.append('<h2>'+folder+f' — {sum(r["status"]=="pass" for r in rs)}/{len(rs)}</h2>')
  for r in rs:
   parts.append('<details class="case"><summary>'+html.escape(r['status']+' '+r['id'])+'</summary><pre>'+html.escape(json.dumps(r,ensure_ascii=False,indent=2))+'</pre>')
   parts.append('<p><a href="'+folder+'/'+r['id']+'-trace.zip">Playwright trace</a></p>')
   for p in sorted((root/folder).glob(r['id']+'-*.png')): parts.append(img_html(p.relative_to(root).as_posix(),p.name))
   parts.append('</details>')
 parts.append('<p>控制台与请求失败原样保留于 results.json。不可将外部字体/Grok 代理错误表述为零控制台错误，也不可将本地摘要保存表述为真实分享。</p>')
 (root/'index.html').write_text('\n'.join(parts))
gallery(final,False);gallery(diag,True)
# File and image integrity validation; browser gallery verification is appended later before packaging.
for root in [final,diag]:
 count=0
 for p in root.rglob('*.png'): Image.open(p).verify();count+=1
 dump(root/'image-integrity.json',{'pngCount':count,'allDecoded':True})
print('ASSEMBLED',len(list(final.rglob('*'))),len(list(diag.rglob('*'))))
